package com.example.nms.ui;

import com.example.nms.config.ConfigBackup;
import com.example.nms.config.ConfigPush;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ConfigController {

    @GetMapping("/config")
    public String configPage(Model model) {
        // Load and display current configuration
        return "config";
    }

    @PostMapping("/backup")
    public String backupConfig() {
        ConfigBackup configBackup = new ConfigBackup();
        configBackup.backupConfig(); // Call the method to backup the config
        return "redirect:/config"; // Redirect to the config page after backup
    }

    @PostMapping("/push")
    public String pushConfig() {
        ConfigPush configPush = new ConfigPush();
        configPush.pushConfig(); // Call the method to push the config
        return "redirect:/config"; // Redirect to the config page after pushing
    }
}
