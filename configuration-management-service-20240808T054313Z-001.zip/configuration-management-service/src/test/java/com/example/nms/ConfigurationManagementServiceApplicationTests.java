package com.example.nms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigurationManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
